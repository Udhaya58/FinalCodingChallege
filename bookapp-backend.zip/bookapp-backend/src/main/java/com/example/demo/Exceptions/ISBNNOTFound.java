package com.example.demo.Exceptions;


public class ISBNNOTFound extends RuntimeException {

	public ISBNNOTFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


	

}
