package com.example.demo.Exceptions;

public class UsernameNotFoundException extends RuntimeException{

	public UsernameNotFoundException(String message) {
		super(message);
	}

}
