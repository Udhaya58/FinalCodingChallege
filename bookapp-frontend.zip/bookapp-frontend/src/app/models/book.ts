export class Book {
    isbn!:number;
    title!:string;
    author!:string;
    publicationyear!:number;
}
