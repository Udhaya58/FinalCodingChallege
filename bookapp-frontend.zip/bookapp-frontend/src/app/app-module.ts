import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Home } from './components/home/home';
import { Getallbook } from './components/getallbook/getallbook';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Addbook } from './components/addbook/addbook';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Update } from './components/update/update';
import { Search } from './components/search/search';
import { Register } from './components/register/register';
import { Login1 } from './components/login1/login1';


@NgModule({
  declarations: [
    App,
    Home,
    Getallbook,
    Addbook,
    Update,
    Search,
    Register,
    Login1,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,FormsModule,ReactiveFormsModule
  ],
  providers: [
    provideBrowserGlobalErrorListeners(),
    
  ],
  bootstrap: [App]
})
export class AppModule { }
