import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from '../models/book';
const baseUrl='http://localhost:9956/auth';
@Injectable({
  providedIn: 'root'
})
export class Bookservice {
  constructor(private http:HttpClient){

  }
  getallbook():Observable<Book[]>{
    return this.http.get<Book[]>(`${baseUrl}/getallbook`);
  }
addbook(book: Book): Observable<Book> {
  return this.http.post<Book>(`${baseUrl}/addbook`, book);
}

updatebook(id:number,book:Book):Observable<Book>{
return this.http.put<Book>(`${baseUrl}/updateBookbyisbn/${id}`,book);


}

getbookbyisbn(id:number):Observable<Book>{
  return this.http.get<Book>(`${baseUrl}/getbookbyisbn/${id}`);
}

deletebookbyisbn(id:number){
  return this.http.delete(`${baseUrl}/deletebyisbn/${id}`,{ responseType: 'text' });
}
}
