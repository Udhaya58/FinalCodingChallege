import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Home } from './components/home/home';
import { Getallbook } from './components/getallbook/getallbook';
import { Addbook } from './components/addbook/addbook';
import { Update } from './components/update/update';
import { Search } from './components/search/search';
import { Register } from './components/register/register';
import { Login1 } from './components/login1/login1';
import { authguardGuard } from './authguard-guard';

const routes: Routes = [
  {
    path:"getallbook",
    component:Getallbook,
    canActivate:[authguardGuard]
  },
  {
    path:'addbook',
    component:Addbook,
     canActivate:[authguardGuard]
  },
  {
    path:'update/:id',
    component:Update,
    canActivate:[authguardGuard]
  },
  {
    path:'search',
    component:Search,
    canActivate:[authguardGuard]
  },
  {
    path:'register',
    component:Register
  },{
    path:'home',
    component:Home,
    canActivate:[authguardGuard]
  },{
    path:'login1',
    component:Login1
  }
  ,{
    path:"",
    component:Login1
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
