import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.html',
  styleUrl: './register.css'
})
export class Register {
registerData = { email: '', password: '' };
  message = '';

  constructor(private http: HttpClient) {}

  onRegister() {
    this.http.post('http://localhost:9956/auth/register', this.registerData)
      .subscribe({
        next: () => {
          this.message = 'Registration successful!';
          this.registerData = { email: '', password: '' };
        },
        error: () => {
          this.message = 'Registration failed. Try again.';
        }
      });
  }
}
