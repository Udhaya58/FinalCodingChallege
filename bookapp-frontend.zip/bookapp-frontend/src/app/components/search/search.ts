import { Component } from '@angular/core';
import { Bookservice } from '../../services/bookservice';
import { Book } from '../../models/book';

@Component({
  selector: 'app-search',
  standalone: false,
  templateUrl: './search.html',
  styleUrl: './search.css'
})
export class Search {
  book!:Book;
  isbn:any;
  notFound = false;
  constructor(private bookser:Bookservice){
  }
  getbookbyisbn(){
    return this.bookser.getbookbyisbn(this.isbn).subscribe({
      next:res=>{
        this.book=res;
        this.notFound=false;
      },
       error: () => {
        this.notFound = true;
      }
    })
  }



}
