import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Getallbook } from './getallbook';

describe('Getallbook', () => {
  let component: Getallbook;
  let fixture: ComponentFixture<Getallbook>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Getallbook]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Getallbook);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
