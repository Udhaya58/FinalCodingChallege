import { Component, OnInit } from '@angular/core';
import { Bookservice } from '../../services/bookservice';
import { Book } from '../../models/book';

@Component({
  selector: 'app-getallbook',
  standalone: false,
  templateUrl: './getallbook.html',
  styleUrl: './getallbook.css'
})
export class Getallbook implements OnInit {
  books:Book[]=[];
  constructor(private bookser:Bookservice){

  }
  
  ngOnInit(){
    this.getallbook();

  }
  getallbook(){
    return this.bookser.getallbook().subscribe({
      next:res=>{
          this.books=res;
      }
    })
  }

  deletebyid(isbn:number){
    return this.bookser.deletebookbyisbn(isbn).subscribe({
      next:res=>{
        this.getallbook();
      }
    })
  }
}
