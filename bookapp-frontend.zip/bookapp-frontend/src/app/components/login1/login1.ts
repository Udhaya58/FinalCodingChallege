import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login1',
  standalone: false,
  templateUrl: './login1.html',
  styleUrl: './login1.css'
})
export class Login1 {
   loginData = { email: '', password: '' };
  errorMessage = '';

  constructor(private http: HttpClient,private router:Router) {}

  onLogin() {
    this.http.post('http://localhost:9956/auth/login', this.loginData)
      .subscribe({
        next: (res: any) => {
          localStorage.setItem('token', res.token); 
          this.errorMessage = '';
          alert('Login Successful!');
          this.router.navigateByUrl('/home');
        },
        error: () => {
          this.errorMessage = 'Invalid credentials!';
        }
      });
  }

}
