import { Component, OnInit } from '@angular/core';
import { Bookservice } from '../../services/bookservice';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Book } from '../../models/book';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addbook',
  standalone: false,
  templateUrl: './addbook.html',
  styleUrl: './addbook.css'
})
export class Addbook implements OnInit {
  successMessage = '';
errorMessage = '';
  constructor(private bookser:Bookservice, private fb:FormBuilder,private router:Router){

  }
  bookForm!:FormGroup;
  ngOnInit(){
    this.bookForm = this.fb.group({
  isbn: ['', [Validators.required, Validators.min(1)]],
  title: ['', [Validators.required, Validators.minLength(2)]],
  author: ['', [Validators.required]],
  publicationyear: ['', [Validators.required, Validators.min(1500), Validators.max(new Date().getFullYear())]]
});


  }
  addbook(){
    return this.bookser.addbook(this.bookForm.value).subscribe({
      next:res=>{
        console.log(res);
        this.successMessage = 'Book added successfully!';
        this.errorMessage = '';
        this.router.navigateByUrl("/getallbook");

        
      },
       error: (err) => {
        console.error('Error adding book:', err);
        this.errorMessage = 'Failed to add book.';
        this.successMessage = '';
      }
    })
  }

}
