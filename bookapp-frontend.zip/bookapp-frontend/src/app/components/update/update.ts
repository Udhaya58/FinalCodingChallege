import { Component, OnInit } from '@angular/core';
import { Bookservice } from '../../services/bookservice';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
@Component({
  selector: 'app-update',
  standalone: false,
  templateUrl: './update.html',
  styleUrl: './update.css'
})
export class Update implements OnInit{

  constructor(private bookser:Bookservice,private fb:FormBuilder,private router:Router,private activatedrouter:ActivatedRoute){

  }

  bookForm!:FormGroup;

isbn!:any;
    ngOnInit(){
      this.isbn = Number(this.activatedrouter.snapshot.paramMap.get('id'));
    this.bookForm = this.fb.group({
  isbn: ['', [Validators.required, Validators.min(1)]],
  title: ['', [Validators.required, Validators.minLength(2)]],
  author: ['', [Validators.required]],
  publicationyear: ['', [Validators.required, Validators.min(1500), Validators.max(new Date().getFullYear())]]
});


}


getbookbyisbn(){
  return this.bookser.getbookbyisbn(this.isbn.value).subscribe({
    next:res=>{
      this.bookForm.patchValue(res);
    }
  })
}

updateBookbyisbn(){
  return this.bookser.updatebook(this.isbn,this.bookForm.value).subscribe({
    next:res=>{
      console.log(res);
      this.router.navigateByUrl("/getallmenu");
    }
  })
}
}
